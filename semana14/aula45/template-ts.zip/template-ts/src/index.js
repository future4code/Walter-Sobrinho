function createPerson(name) {
    return { name: name };
}
var myPerson1 = createPerson();
var myPerson2 = createPerson("Robson");
console.log(myPerson1);
console.log(myPerson2);
