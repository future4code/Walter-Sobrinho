"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.myFunc = void 0;
function myFunc() {
    return "Olá mundo, sou uma mensagem da AWS";
}
exports.myFunc = myFunc;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsU0FBZ0IsTUFBTTtJQUNwQixPQUFPLG9DQUFvQyxDQUFDO0FBQzlDLENBQUM7QUFGRCx3QkFFQyJ9